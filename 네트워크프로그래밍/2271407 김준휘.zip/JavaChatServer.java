//JavaChatServer.java (Java Chatting Server)

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class JavaChatServer extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    JTextArea textArea;
    private JTextField txtPortNumber;

    private ServerSocket socket; // 서버소켓
    private Socket client_socket; // accept() 에서 생성된 client 소켓, AcceptServer에서 지역변수로 선언해도 됩니다. 
    private Vector<UserService> UserVec = new Vector<>(); // 연결된 사용자를 저장할 벡터, ArrayList와 같이 동적 배열을 만들어주는 컬렉션 객체
    private static final int BUF_LEN = 128; // Windows 처럼 BUF_LEN 을 정의
    private static final String[] BAD_WORDS = { "바보", "멍청이", "욕설" }; // 금칙어 목록

    /**
     * Launch the application.
     */
    public static void main(String[] args) {   // 스윙 비주얼 디자이너를 이용해 GUI를 만들면 자동으로 생성되는 main 함수
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    JavaChatServer frame = new JavaChatServer();      // JavaChatServer 클래스의 객체 생성
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public JavaChatServer() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 338, 386);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(12, 10, 300, 244);
        contentPane.add(scrollPane);

        textArea = new JTextArea();
        textArea.setEditable(false);
        scrollPane.setViewportView(textArea);

        JLabel lblNewLabel = new JLabel("Port Number");
        lblNewLabel.setBounds(12, 264, 87, 26);
        contentPane.add(lblNewLabel);

        txtPortNumber = new JTextField();
        txtPortNumber.setHorizontalAlignment(SwingConstants.CENTER);
        txtPortNumber.setText("30000");
        txtPortNumber.setBounds(111, 264, 199, 26);
        contentPane.add(txtPortNumber);
        txtPortNumber.setColumns(10);

        JButton btnServerStart = new JButton("Server Start");
        btnServerStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    socket = new ServerSocket(Integer.parseInt(txtPortNumber.getText()));
                } catch (NumberFormatException | IOException e1) {
                    e1.printStackTrace();
                }
                AppendText("Chat Server Running..");
                btnServerStart.setText("Chat Server Running..");
                btnServerStart.setEnabled(false); // 서버를 더이상 실행시키지 못 하게 막는다
                txtPortNumber.setEnabled(false); // 더이상 포트번호 수정못 하게 막는다
                AcceptServer accept_server = new AcceptServer();   // 멀티 스레드 객체 생성
                accept_server.start();
            }
        });
        btnServerStart.setBounds(12, 300, 300, 35);
        contentPane.add(btnServerStart);
    }

    
    // 새로운 참가자 accept() 하고 user thread를 새로 생성한다. 한번 만들어서 계속 사용하는 스레드
    class AcceptServer extends Thread {
        public void run() {
            while (true) { // 사용자 접속을 계속해서 받기 위해 while문
                try {
                    AppendText("Waiting clients ...");
                    client_socket = socket.accept(); // accept가 일어나기 전까지는 무한 대기중
                    AppendText("새로운 참가자 from " + client_socket);
                    // User 당 하나씩 Thread 생성
                    UserService new_user = new UserService(client_socket);
                    UserVec.add(new_user); // 새로운 참가자 배열에 추가
                    AppendText("사용자 입장. 현재 참가자 수 " + UserVec.size());
                    new_user.start(); // 만든 객체의 스레드 실행
                } catch (IOException e) {
                    AppendText("!!!! accept 에러 발생... !!!!");
                }
            }
        }
    }
    // 지금은 보다 심플한 코드를 위해 서버는 계속 켜져 있는 것으로 가정하였으나(AcceptServer 스레스 종료 X)
    // 서버를 정상적으로 종료하고 싶은 경우, 서버 GUI에 종료 버튼을 만들어 서버소켓을 닫는 스레드를 추가로 만들거나,
    // 또는 GUI 창이 닫히는 순간(addWindowListener의 windowClosing 메서드 등에서)
    // ServerSocket.close()를 호출하여 accept()를 깨워서 AcceptServer를 종료하는 방법이나 플래그 신호 사용 방법 등이 있을 수 있음
    
    
    //JtextArea에 문자열을 출력해 주는 기능을 수행하는 맴버 함수
    public void AppendText(String str) {
        textArea.append(str + "\n");   //전달된 문자열 str을 textArea에 추가
        textArea.setCaretPosition(textArea.getText().length());  // textArea의 커서(캐럿) 위치를 텍스트 영역의 마지막으로 이동
    }

    
    // User 당 생성되는 Thread, 유저의 수만큼 스레스 생성
    // 이 UserService 스레드는 '소켓 객체'를 이용해서 실제 특정 유저와 메시지를 주고 받는 기능을 수행하는 스레드
    // 이 스레드 클래스의 run() 메소드 안의 dis.readUTF()에서 대기하다가 메시지가 들어오면 -> Write All로 전체 접속한 사용자한테 전송(단톡방) 
    class UserService extends Thread {
    	//참고로 서버와 클라이언트 사이의 1:1 채팅이 아니기 때문에 
    	//(서버에서는) 서버가 스스로 메시지를 먼저 보낼 일이 없으니(한 클라이언트한테 받은 메시지를 다른 클라이언트들한테 전달만 하면 됩니다)
    	//따라서 run() 안에 작성되어 있는 '보내는 기능을 수행하는 코드'와 '받는 기능을 수행하는 코드'를 이 서버에서는 스레드로 분리할 필요가 없음
    	
        private InputStream is;
        private OutputStream os;
        private DataInputStream dis;
        private DataOutputStream dos;
        private Socket client_socket;
        private Vector<UserService> user_vc; // 제네릭 타입 사용
        private String UserName = "";

        public UserService(Socket client_socket) {
            // 매개변수로 넘어온 소켓 객체 저장 
            this.client_socket = client_socket;
            this.user_vc = UserVec;
            try {
                is = client_socket.getInputStream();
                dis = new DataInputStream(is);
                os = client_socket.getOutputStream();
                dos = new DataOutputStream(os);
                String line1 = dis.readUTF();      // 제일 처음 연결되면 클라이언트의 SendMessage("/login " + UserName);에 의해 "/login UserName" 문자열이 들어옴
                String[] msg = line1.split(" ");   //line1이라는 문자열을 공백(" ")을 기준으로 분할
                UserName = msg[1].trim();          //분할된 문자열 배열 msg의 두 번째 요소(인덱스 1)를 가져와 trim 메소드를 사용하여 앞뒤의 공백을 제거
                AppendText("새로운 참가자 " + UserName + " 입장.");
                WriteOne("Welcome to Java chat server\n");
                WriteOne(UserName + "님 환영합니다.\n"); // 연결된 사용자에게 정상접속을 알림
                String br_msg ="["+UserName+"]님이 입장 하였습니다.\n";    //broadcastMessage 생성 [추가]
                WriteAll(br_msg); // broadcastMessage 전송, 아직 user_vc에 새로 입장한 user는 포함되지 않았으므로 새로운 참가자한테는 전송하지 않음 [추가]
            } catch (Exception e) {
                AppendText("userService error");
            }
        }


        public void logout() {
            UserVec.removeElement(this); // 에러가난 현재 객체를 벡터에서 지운다
        	String br_msg ="["+UserName+"]님이 퇴장 하였습니다.\n";   // 다른 User들에게 전송할 메시지 생성  [추가]
        	WriteAll(br_msg); // 다른 User들에게 전송  [추가]
            AppendText("사용자 퇴장. 현재 참가자 수 " + UserVec.size());
        }
        
        // 클라이언트로 메시지 전송
        public void WriteOne(String msg) {
            try {
                dos.writeUTF(msg);
            } catch (IOException e) {
                AppendText("dos.write() error");
                try {
                    dos.close();
                    dis.close();
                    client_socket.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                logout();
            }
        }

        
        //모든 다중 클라이언트에게 순차적으로 채팅 메시지 전달
        public void WriteAll(String str) {  
            for (int i = 0; i < user_vc.size(); i++) {
            	UserService user = user_vc.get(i);     // get(i) 메소드는 user_vc 컬렉션의 i번째 요소를 반환
                user.WriteOne(str);
            }
        }
        
        
        public void run() {
        	// dis.readUTF()에서 대기하다가 메시지가 들어오면 -> Write All로 전체 접속한 사용자한테 메시지 전송(단톡방), 이걸 클라이언트별로 무한히 실행
        	// 추가적으로 지금은 dis.readUTF()에서 예외가 발생하면 '예외처리에 의해 정상적으로 스레드가 종료하게 작성'되었으나
        	// '/exit'가 들어와도 종료하게 코드를 추가하면 더 완성도 있는 코드가 됩니다.
        	// 지금은 다양한 사용자 프로토콜(/list, /to, /exit 등)을 정의하고 있지 않지만 추후 /exit 프로토콜 등의 정의시 추가
            while (true) {
                try {
                    String msg = dis.readUTF(); 
                    msg = msg.trim();   //msg를 가져와 trim 메소드를 사용하여 앞뒤의 공백을 제거
                    String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")); // 현재 시간을 "HH:mm:ss" 형식으로 포맷하여 문자열로 변환
                    String timedMsg = "[" + time + "] " + msg;
                    String[] args = msg.split("\\s+"); // 명령어와 매개변수 분리
                    AppendText(timedMsg); 
                    if (args.length < 2) continue; // 빈 메시지는 무시
                    
                    // 명령어 처리
                    switch (args[1]) {
                        case "/help": // 명령어 도움말
                            WriteOne("**명령어 도움말**\n"
                                    + "/help : 명령어 안내\n"
                                    + "/count : 현재 접속자 수\n"
                                    + "/list : 접속자 목록\n"
                                    + "/to 이름 메시지 : 귓속말\n"
                                    + "/exit : 채팅 종료\n");
                            break;

                        case "/count": // 현재 접속자 수
                            WriteOne("현재 접속자는 " + UserVec.size() + "명입니다.\n");
                            break;

                        case "/exit": // 종료 명령
                            AppendText(timedMsg);
                            logout(); // 사용자 로그아웃 처리
                            return; // 스레드 종료

                        case "/list": // 접속자 목록 보기
                            WriteOne("**현재 사용자 목록**\n");
                            for (int i = 0; i < user_vc.size(); i++) {
                                UserService user = user_vc.get(i); // 명시적인 인덱스 접근
                                WriteOne("- " + user.UserName + "\n");
                            }
                            break;

                        case "/to": // 귓속말 처리, [홍길동] /to 신데렐라 안녕~ 반갑다. ^^\n
                            if (args.length < 4) {
                                WriteOne("사용법: /to [username] [message]\n");
                                break;
                            }
                            String targetUser = args[2];
                            String privateMessage = "";
                            for (int i = 3; i < args.length; i++) {
                                privateMessage += args[i];
                                if (i < args.length - 1) privateMessage += " ";
                            }
                            boolean found = false;
                            for (int i = 0; i < user_vc.size(); i++) {
                                UserService user = user_vc.get(i); // 명시적인 인덱스 접근
                                if (user.UserName.equals(targetUser)) {
                                    user.WriteOne("[" + UserName + "님의 귓속말] " + privateMessage + "\n");
                                    WriteOne("[" + UserName + "님의 귓속말] " + privateMessage + "\n");
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                WriteOne("사용자 " + targetUser + "를 찾을 수 없습니다.\n");
                            }
                            break;

                        default: // 일반 메시지 처리
                            // 사용자 이름은 유지하고, 메시지 본문에 포함된 금칙어만 변경
                            String[] parts = msg.split("\\s+", 2);
                            String message = parts[1];
                            for (String word : BAD_WORDS) {
                                message = message.replace(word, "***");
                            }
                            timedMsg = "[" + time + "] " + parts[0] + " " + message;
                            WriteAll(timedMsg + "\n"); // 모든 사용자에게 메시지 전송
                            break;
                    }
                    
                    
                    
                } catch (IOException e) {
                    AppendText("dis.readUTF() error");
                    try {
                        dos.close();
                        dis.close();
                        client_socket.close();
                        logout();
                        break;  
                    } catch (Exception ee) {
                        break;
                    } 
                }
            }
        }
        
    }
}

